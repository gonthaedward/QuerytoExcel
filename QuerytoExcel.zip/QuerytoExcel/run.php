<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database
$servername = "localhost"; 
$username = "matamatasakamata";
$password = "matamatasakamata";
$dbname = "matamatasakamata";

// Connect
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch data (Update this if you want to get other table 
//[PLEASE only update the name of table you want to select, the table, and the WHERE condition])
//[If possible, LIMIT the query to max 1000 as the loading would be really long]
$query = "SELECT * FROM product_variant_code_with_info WHERE 1=1 LIMIT 1000"; 

// Validation to make sure that user updated $query into only "SELECT"
$queryTrim = ltrim($query);
$mainQuery = preg_replace('/\(.+\)/U', '', $queryTrim); 

if(stripos($queryTrim,'SELECT')===0)
{
    $result = $conn->query($query);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    // Create a new Spreadsheet object
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Get column headers dynamically
    $fields = $result->fetch_fields();
    $headers = [];
    foreach ($fields as $field) {
        $headers[] = $field->name; // Extract column name
    }

    // Add headers to the sheet
    $sheet->fromArray($headers, NULL, 'A1'); // Add headers starting from A1

    // Add data rows to the sheet
    $rowIndex = 2; // Start from the second row (below headers)
    while ($row = $result->fetch_assoc()) {
        $sheet->fromArray(array_values($row), NULL, 'A' . $rowIndex);
        $rowIndex++;
    }

    // Save the file to the local directory
    // 
    $saveDirectory = 'C:\\Users\\Eda\\Downloads';
    $fileName = $saveDirectory . DIRECTORY_SEPARATOR . 'GeneratedTable.xlsx';
    $writer = new Xlsx($spreadsheet);
    try {
        $writer->save($fileName);
        echo "File generated successfully: $fileName\n";
    } catch (Exception $e) {
        echo "Error writing file: " . $e->getMessage() . "\n";
    }

    // Close the database connection
    $conn->close();
    exit;
}
else{
    echo "Invalid Query, please make sure it start with SELECT (e.g: select * from table)";
}
?>